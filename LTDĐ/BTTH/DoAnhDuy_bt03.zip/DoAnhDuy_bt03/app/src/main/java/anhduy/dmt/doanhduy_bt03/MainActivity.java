package anhduy.dmt.doanhduy_bt03;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements ContactsAdapter.Listener{

    RecyclerView rvContacts;
    ArrayList<Contacts> contacts;
    ContactsAdapter contactsAdapter;
    FloatingActionButton fabAddContact;
    int position;


    ActivityResultLauncher<Intent> Mlauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if(result.getResultCode()==RESULT_OK){
                        if(result.getData().getIntExtra("flag",0)==1){
                            Contacts contacts =(Contacts) result.getData().getSerializableExtra("contact");
                            contactsAdapter.addContact(contacts);
                        }
                        else{
                            Contacts contacts =(Contacts) result.getData().getSerializableExtra("contact");
                            contactsAdapter.editContact(contacts,position);
                        }
                    }
                }
            }
    );
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setTitle("Contact");

        rvContacts=findViewById(R.id.rvContacts);
        fabAddContact=findViewById(R.id.fabAddContact);
        fabAddContact.setOnClickListener( v -> {
            Intent intent = new Intent(MainActivity.this, AddEditActivity.class);
            intent.putExtra("contact", contacts);
            intent.putExtra("flag", 1);
            Mlauncher.launch(intent);
           // dismiss();
        });
        contacts=Apps.initDataForContacts();
        contactsAdapter = new ContactsAdapter(contacts,MainActivity.this);
        rvContacts.setAdapter(contactsAdapter);

        rvContacts.setLayoutManager(new LinearLayoutManager(MainActivity.this, LinearLayoutManager.VERTICAL, false));
        rvContacts.addItemDecoration(new DividerItemDecoration(MainActivity.this, LinearLayoutManager.VERTICAL));

    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_main, menu);

        SearchView searchView  = (SearchView) menu.findItem(R.id.action_search).getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                contactsAdapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                contactsAdapter.getFilter().filter(newText);

                if(newText.isEmpty()){
                    fabAddContact.setVisibility(View.VISIBLE);
                }else {
                    fabAddContact.setVisibility(View.INVISIBLE);
                }
                return false;
            }
        });
        return true;
    }

//    @Override
//    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
//        if(item.getItemId() == R.id.mnuSort){
//            Collections.sort(contacts);
//            contactAdapter.notifyDataSetChanged();
//        }
//        if(item.getItemId() == R.id.mnuSearch){
//            Intent intent = new Intent(MainActivity.this, SearchActivity.class);
//            startActivity(intent);
//        }
//        return super.onOptionsItemSelected(item);
//    }


    @Override
    public void OnItemListener(int pos, Contacts contact) {
        InfoDialogBottomSheet dialog= new InfoDialogBottomSheet(this,contact,Mlauncher ,contactsAdapter);

        dialog.findView();
        dialog.show();
    }
}