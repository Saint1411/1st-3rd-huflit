package anhduy.dmt.doanhduy_bt03;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import java.util.ArrayList;
import java.util.List;
import java.util.Locale;


import de.hdodenhof.circleimageview.CircleImageView;

public class ContactsAdapter extends RecyclerView.Adapter<ContactsAdapter.ContactVH> implements Filterable{
    ArrayList<Contacts> contacts;
    ArrayList<Contacts> contactsFilter;
    Listener listener;

    public ContactsAdapter(ArrayList<Contacts> contacts, Listener listener) {
        this.contacts = contacts;
        this.listener = listener;
        this.contactsFilter = contacts;
    }

    @NonNull
    @Override
    public ContactsAdapter.ContactVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.contact_row, parent,false);
        return new ContactVH(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ContactVH holder,  int position) {
        Contacts contact = contacts.get(position);
        holder.imgFlag.setImageResource(contact.getImg());
        holder.txFname.setText(contact.getFname());
        holder.txLname.setText(contact.getLname());
        holder.txPhone.setText(contact.getPhone());
        holder.txEmail.setText(contact.getEmail());
        if(contact.getImg() == 0){
            holder.imgFlag.setImageResource(R.drawable.ic_baseline_add_circle_24);
        }else {
            holder.imgFlag.setImageResource(contact.getImg());
        }
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.OnItemListener(position,contact);
            }
        });
    }

    @Override
    public int getItemCount() {
        //return contactsFilter.size();
        return contacts.size();
    }

    @Override
    public Filter getFilter() {
        return new ContactFilter();
    }
    class ContactFilter extends Filter{

        @Override
        protected FilterResults performFiltering(CharSequence charSequence) {
            String charString = charSequence.toString();
            if (charString.isEmpty()) {
                contactsFilter = contacts;
            } else {
                List<Contacts> filteredList = new ArrayList<>();
                for (Contacts row : contacts) {
                    if(row.getFname().toLowerCase().contains(charString.toLowerCase())) {
                        filteredList.add(row);
                    }

                }

                contactsFilter = (ArrayList<Contacts>) filteredList;
            }

            FilterResults filterResults = new FilterResults();
            filterResults.values = contactsFilter;
            return filterResults;
        }

        @Override
        protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
            contactsFilter= (ArrayList<Contacts>) filterResults.values;
            notifyDataSetChanged();
        }
    }


    class ContactVH extends RecyclerView.ViewHolder{
        CircleImageView imgFlag;
        TextView txFname, txLname, txPhone, txEmail;


        public ContactVH(@NonNull View itemView) {
            super(itemView);
            imgFlag = itemView.findViewById(R.id.imgFlag);
            txFname = itemView.findViewById(R.id.txFname);
            txLname = itemView.findViewById(R.id.txLname);
            txPhone = itemView.findViewById(R.id.txPhone);
            txEmail = itemView.findViewById(R.id.txEmail);
        }
    }

    public void addContact(Contacts contact){
        contacts.add(contact);
        notifyDataSetChanged();
    }

    public void editContact(Contacts contact, int pos){
        contacts.set(pos, contact);
        notifyDataSetChanged();
    }

//    public void deleteContact(int pos){
//        contactsFilter.remove(pos);
//        notifyDataSetChanged();
//    }

    public void deleteContact(Contacts contact){
        contacts.remove(contact);
        notifyDataSetChanged();
    }

    interface Listener{
        void OnItemListener(int pos, Contacts contact);
        //void onItemListener(Contacts contact);
    }

}
