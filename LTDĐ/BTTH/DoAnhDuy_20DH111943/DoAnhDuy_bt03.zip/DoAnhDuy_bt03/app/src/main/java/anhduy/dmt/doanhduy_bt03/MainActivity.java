package anhduy.dmt.doanhduy_bt03;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class MainActivity extends AppCompatActivity implements ContactsAdapter.Listener{

    RecyclerView rvContacts;
    ArrayList<Contacts> contacts;
    Contacts contacts1;
    ContactsAdapter contactsAdapter;
    FloatingActionButton btAdd;
    private SearchView searchView;
    int position;


    ActivityResultLauncher<Intent> Mlauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if(result.getResultCode()==RESULT_OK){
                        if(result.getData().getIntExtra("flag",0)==1){
                            Contacts contacts =(Contacts) result.getData().getSerializableExtra("contact");
                            contactsAdapter.addContact(contacts);
                        }
                        else{
                            Contacts contacts =(Contacts) result.getData().getSerializableExtra("contact");
                            contactsAdapter.editContact(contacts,position);
                        }
                    }
                }
            }
    );
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setTitle("Contact");

        rvContacts=findViewById(R.id.rvContacts);
        btAdd=findViewById(R.id.btAdd);
        btAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AddEditActivity.class);
                intent.putExtra("contact", contacts);
                intent.putExtra("flag", 1);
                Mlauncher.launch(intent);
            }
        });
        contacts=Apps.initDataForContacts();
        contactsAdapter = new ContactsAdapter(contacts,MainActivity.this);
        rvContacts.setAdapter(contactsAdapter);

        rvContacts.setLayoutManager(new LinearLayoutManager(MainActivity.this, LinearLayoutManager.VERTICAL, false));
        rvContacts.addItemDecoration(new DividerItemDecoration(MainActivity.this, LinearLayoutManager.VERTICAL));

    }

//    @Override
//    public void onItemListener(int position,Contacts contact) {
//
//        InfoDialogBottomSheet dialog= new InfoDialogBottomSheet(this,contact,Mlauncher ,contactsAdapter);
//
//        dialog.findView();
//        dialog.show();

//        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
//        builder.setTitle("Contacts");
//        builder.setIcon(getDrawable(contact.getImg()));
//        builder.setMessage(contact.getFname()+ ' '+contact.getLname()+ '\n'+ contact.getPhone());
//        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialogInterface, int i) {
//                dialogInterface.dismiss();
//            }
//        });
//        AlertDialog alertDialog = builder.create();
//        alertDialog.show();



//    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_main, menu);

        searchView  = (SearchView) menu.findItem(R.id.action_search).getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                contactsAdapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                contactsAdapter.getFilter().filter(newText);
//                if(newText.isEmpty()){
//                    btAdd.setVisibility(View.VISIBLE);
//                }else {
//                    btAdd.setVisibility(View.INVISIBLE);
//                }
                return false;
            }
        });
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.action_sort){

            SortContact(contacts);
            contactsAdapter.notifyDataSetChanged();
        }
        return super.onOptionsItemSelected(item);
    }

    public void SortContact(ArrayList<Contacts> contacts) {
        Collections.sort(contacts, new Comparator<Contacts>() {
            @Override
            public int compare(Contacts t1, Contacts t2) {
                String word1 = t1.getFname();
                String word2 = t2.getFname();
                int compareWord = word1.compareTo(word2);

                return compareWord;
            }
        });
    }
    @Override
    public void OnItemListener(int pos, Contacts contact) {
        InfoDialogBottomSheet dialog= new InfoDialogBottomSheet(this,contact,Mlauncher ,contactsAdapter);

        dialog.findView();
        dialog.show();
    }
}