package anhduy.dmt.doanhduy_bt03;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

//import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.ActivityResultLauncher;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;

import com.google.android.material.bottomsheet.BottomSheetDialog;

public class InfoDialogBottomSheet extends BottomSheetDialog {
    TextView txFullName, txPhone, txEmail, txBirthday;
    ImageView imImage;
    ImageButton btnClose, btnEdit, btnDelete;
    Contacts contact;
    ActivityResultLauncher mLauncher;
    ContactsAdapter contactAdapter;


    public InfoDialogBottomSheet(@NonNull Context context, Contacts contact,ActivityResultLauncher mLauncher, ContactsAdapter contactAdapter) {
        super(context);
        this.contact = contact;
        this.mLauncher = mLauncher;
        this.contactAdapter = contactAdapter;


    }

    public void findView() {
        View view = getLayoutInflater().inflate(R.layout.activity_info, null);

        txFullName = view.findViewById(R.id.fullName);
        txPhone = view.findViewById(R.id.txPhone);
        txEmail = view.findViewById(R.id.txEmail);
        txBirthday = view.findViewById(R.id.txBirthday);
        imImage = view.findViewById(R.id.userImage);
        btnClose = view.findViewById(R.id.cancelBtn);
        btnClose.setOnClickListener(v -> {
            this.dismiss();
        });
        btnEdit = view.findViewById(R.id.editBtn);
        btnEdit.setOnClickListener( v -> {
            Intent intent = new Intent(getContext(), AddEditActivity.class);
            intent.putExtra("contact", contact);
            intent.putExtra("flag", 2);
            mLauncher.launch(intent);
            dismiss();
        });
        btnDelete = view.findViewById(R.id.deleteBtn);
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                builder.setTitle("Contacts");
                builder.setMessage("Delete ".concat(contact.getLname()).concat(" ?"));
                builder.setNegativeButton("No", (dialogInterface, i) -> {
                    dialogInterface.cancel();

                });
                builder.setPositiveButton("Yes", (dialogInterface, i) -> {
                    contactAdapter.deleteContact(contact);
                    dialogInterface.dismiss();
                    dismiss();
                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();

            }
        });
        txFullName.setText(contact.getFname()+ " " +contact.getLname());
        txEmail.setText(contact.getEmail());
        txPhone.setText(contact.getPhone());
        txBirthday.setText(contact.getBirthday());
        imImage.setImageResource(contact.getImg());

        setContentView(view);

    }
}
