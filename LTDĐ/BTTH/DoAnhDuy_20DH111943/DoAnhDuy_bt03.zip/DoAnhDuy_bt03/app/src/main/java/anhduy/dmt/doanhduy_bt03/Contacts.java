package anhduy.dmt.doanhduy_bt03;

import java.io.Serializable;
import java.util.Collections;

public class Contacts implements Serializable {
    int id;
    String fname;
    String lname;
    int img;
    String phone;
    String email;
    String birthday;

    //    contacts contact = new Contacts(new Random().nextInt(9999),
//            edfName.getText().toString(),
//            edlName.getText().toString(),
//            0,
//            edPhone.getText().toString(),
//            edEmail.getText().toString(),
//            edBirthday.getText().toString());
    public Contacts(int id, String fname,String lname, int img, String phone, String email, String birthday) {
        this.id = id;
        this.fname = fname;
        this.lname=lname;
        this.img = img;
        this.phone = phone;
        this.email = email;
        this.birthday=birthday;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }



}
